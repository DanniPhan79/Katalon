<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>lbl_text contains</name>
   <tag></tag>
   <elementGuidId>d5ac1234-3519-42e2-b412-3db0cf732dc0</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[contains(@text,&quot;${text}&quot;)]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
