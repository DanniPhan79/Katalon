<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnLogout</name>
   <tag></tag>
   <elementGuidId>7cdaec9e-c177-4366-9659-3ac5494594cf</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text=&quot;Đăng xuất&quot;]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
