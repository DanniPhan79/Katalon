<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>optLoginAndAuthentication</name>
   <tag></tag>
   <elementGuidId>c74ad5ad-489a-4bef-9bb1-38be5a0159da</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@resource-id='SIDEBAR_ITEM_1']/android.widget.TextView</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
