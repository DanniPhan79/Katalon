<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>optPersonalInformation</name>
   <tag></tag>
   <elementGuidId>dc437aad-f0ca-411f-b545-ee2a1a80d592</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@resource-id='SIDEBAR_ITEM_0']/android.widget.TextView</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
