<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnHidden</name>
   <tag></tag>
   <elementGuidId>f176b77a-f762-4313-9fc9-d8d1aa70a4d2</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@class = 'android.widget.ImageView' and @resource-id = 'vn.com.ocb.awe.uat:id/imgSecureAccountNumberToggle' and (@text = '' or . = '')]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
