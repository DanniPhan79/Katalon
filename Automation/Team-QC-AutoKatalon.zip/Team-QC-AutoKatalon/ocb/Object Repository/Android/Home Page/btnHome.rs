<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnHome</name>
   <tag></tag>
   <elementGuidId>ef8d8bfd-f144-4f84-8908-ee1f95b36355</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>android.widget.Button</value>
      <webElementGuid>4e1f95bf-2bea-4cb9-808d-2b42ddafd261</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>resource-id</name>
      <type>Main</type>
      <value>tabhome</value>
      <webElementGuid>840a0beb-7d9a-4ee5-81b2-8d5934924755</webElementGuid>
   </webElementProperties>
   <locator>//*[@class = 'android.widget.Button' and @resource-id = 'tabhome']</locator>
   <locatorStrategy>ATTRIBUTES</locatorStrategy>
</MobileElementEntity>
