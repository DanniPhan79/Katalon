<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnSideMenu</name>
   <tag></tag>
   <elementGuidId>49ed1cf8-6d07-4cdc-bb18-c02ae892ced3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>((//*[@resource-id='HOME_PAGE_SCROLL_VIEW']/../../android.view.ViewGroup)[2]//android.widget.ImageView)[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
