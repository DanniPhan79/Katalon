<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>lblFavoriteTransactions</name>
   <tag></tag>
   <elementGuidId>729e5f38-f350-4da6-a6e9-d20c6cfe2e68</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>android.widget.TextView</value>
      <webElementGuid>4ed877ac-0451-4f4d-8d40-4449669f3782</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>GIAO DỊCH ƯA THÍCH</value>
      <webElementGuid>241a4736-9183-47b6-a9f0-2e14bcb4119c</webElementGuid>
   </webElementProperties>
   <locator>//*[@class = 'android.widget.TextView' and (@text = 'GIAO DỊCH ƯA THÍCH' or . = 'GIAO DỊCH ƯA THÍCH')]</locator>
   <locatorStrategy>ATTRIBUTES</locatorStrategy>
</MobileElementEntity>
