<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>lblProductsAndServices</name>
   <tag></tag>
   <elementGuidId>dba755cb-191f-4143-a733-eb6cbe7029c6</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>android.widget.TextView</value>
      <webElementGuid>01ad4e95-9f74-4a20-8945-aba088fe3ed9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>SẢN PHẨM &amp; DỊCH VỤ</value>
      <webElementGuid>88b00a8d-3f73-4407-9a9e-e4e15e38edd5</webElementGuid>
   </webElementProperties>
   <locator>//*[@class = 'android.widget.TextView' and (@text = 'SẢN PHẨM &amp; DỊCH VỤ' or . = 'SẢN PHẨM &amp; DỊCH VỤ')]</locator>
   <locatorStrategy>ATTRIBUTES</locatorStrategy>
</MobileElementEntity>
