<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>lblTotalAvailableAccountBalance</name>
   <tag></tag>
   <elementGuidId>1c0e8b5f-a7ef-4933-abcb-0fa8a32e9ff7</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>android.widget.TextView</value>
      <webElementGuid>fb7426d5-6ab0-406d-beb0-f1231329b12a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>TỔNG SỐ DƯ KHẢ DỤNG</value>
      <webElementGuid>25ded26a-be22-4885-8882-5effb311ce89</webElementGuid>
   </webElementProperties>
   <locator>//*[@class = 'android.widget.TextView' and (@text = 'TỔNG SỐ DƯ KHẢ DỤNG' or . = 'TỔNG SỐ DƯ KHẢ DỤNG')]</locator>
   <locatorStrategy>ATTRIBUTES</locatorStrategy>
</MobileElementEntity>
