<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>optServiceName</name>
   <tag></tag>
   <elementGuidId>c3a14166-cdcb-4268-8c8c-b125eb09bdfd</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>android.widget.TextView</value>
      <webElementGuid>34db8488-e671-4404-8a23-99a82eca195d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>${text}</value>
      <webElementGuid>54edf93e-6b36-41bd-91d8-5a3f9334bd44</webElementGuid>
   </webElementProperties>
   <locator>//android.widget.TextView[@text = '${text}' or . = '${text}']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
