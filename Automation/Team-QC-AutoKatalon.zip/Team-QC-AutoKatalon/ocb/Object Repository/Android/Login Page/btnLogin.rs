<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnLogin</name>
   <tag></tag>
   <elementGuidId>f6684c41-8563-4981-8384-887f67b6301d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>android.widget.TextView</value>
      <webElementGuid>aac0d0e4-3512-4baf-bc33-a78f0ae3055f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Đăng nhập</value>
      <webElementGuid>28181d6b-7dab-4c0a-84d3-bf655db9e9a2</webElementGuid>
   </webElementProperties>
   <locator>//*[@class = 'android.widget.Button' and (@text = 'Đăng nhập' or . = 'Đăng nhập') and @resource-id = 'vn.com.ocb.awe.uat:id/btnLogin']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
