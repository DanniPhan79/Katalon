<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnRefreshAccount</name>
   <tag></tag>
   <elementGuidId>324988ff-aadc-4fda-9a9a-8cff5a77e54d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[@class = 'android.widget.TextView' and (@text = '' or . = '')]/..//android.widget.TextView)[4]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
