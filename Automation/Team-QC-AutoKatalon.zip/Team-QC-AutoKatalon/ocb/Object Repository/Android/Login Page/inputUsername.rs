<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>inputUsername</name>
   <tag></tag>
   <elementGuidId>995ece89-2e2b-44df-97aa-3223ff69c7d4</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.view.ViewGroup[2]/android.view.ViewGroup[1]/android.widget.EditText[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
