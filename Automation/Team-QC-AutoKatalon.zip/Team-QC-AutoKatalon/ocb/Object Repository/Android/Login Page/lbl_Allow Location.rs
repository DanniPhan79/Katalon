<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>lbl_Allow Location</name>
   <tag></tag>
   <elementGuidId>14e30ebc-dd66-4a5d-85be-200e3e03cde2</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>android.widget.Button</value>
      <webElementGuid>b7a7230c-15f0-452d-a4b6-ac8eba0a740e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>resource-id</name>
      <type>Main</type>
      <value>com.android.permissioncontroller:id/permission_allow_foreground_only_button</value>
      <webElementGuid>c4af0051-549d-49e9-b418-f310f7f92086</webElementGuid>
   </webElementProperties>
   <locator>//*[@class = 'android.widget.Button' and @resource-id = 'com.android.permissioncontroller:id/permission_allow_foreground_only_button']</locator>
   <locatorStrategy>ATTRIBUTES</locatorStrategy>
</MobileElementEntity>
