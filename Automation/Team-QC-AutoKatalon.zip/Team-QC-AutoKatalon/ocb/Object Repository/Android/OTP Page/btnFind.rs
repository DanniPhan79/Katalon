<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnFind</name>
   <tag></tag>
   <elementGuidId>2442eadc-7692-4ece-85ce-8ed7ba460f8d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@class = 'android.widget.Button' and (@text = ' Tìm ' or . = ' Tìm ') and @resource-id = 'btnExecute']</locator>
   <locatorStrategy>ATTRIBUTES</locatorStrategy>
</MobileElementEntity>
