<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>buttonNewTab</name>
   <tag></tag>
   <elementGuidId>3b907159-26eb-48a7-9d2f-0aafcc445316</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.ImageView[@content-desc=&quot;New tab&quot;]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
