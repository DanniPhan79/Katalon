<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>ddSmsSend</name>
   <tag></tag>
   <elementGuidId>3ff4b1eb-afb8-44cc-a0f9-21e862cbddca</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@class = 'android.view.View' and (@text = 'SMS_SEND' or . = 'SMS_SEND') and @resource-id = 'cboSmsTypes']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
