<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>ddUatEnv</name>
   <tag></tag>
   <elementGuidId>da3212f7-9158-45bf-9cd7-24299b9c61c3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[(@text = 'Môi trường UAT AWS' or . = 'Môi trường UAT AWS')]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
