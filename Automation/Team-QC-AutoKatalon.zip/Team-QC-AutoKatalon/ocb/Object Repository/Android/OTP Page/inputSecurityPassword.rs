<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>inputSecurityPassword</name>
   <tag></tag>
   <elementGuidId>756f48d9-e420-4b96-95d3-ba9a298d9e41</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//android.widget.FrameLayout[@resource-id=&quot;vn.com.ocb.awe.uat:id/passcode_textview&quot;])[2]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
