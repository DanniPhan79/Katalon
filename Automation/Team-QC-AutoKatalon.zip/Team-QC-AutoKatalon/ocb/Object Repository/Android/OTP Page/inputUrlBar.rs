<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>inputUrlBar</name>
   <tag></tag>
   <elementGuidId>556e4478-eeff-4ec7-adf1-4ac9de582adb</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@resource-id = 'com.android.chrome:id/url_bar']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
