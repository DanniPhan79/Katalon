<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>optUatEnv</name>
   <tag></tag>
   <elementGuidId>77850a2e-82a3-419d-a8b7-9581813b5505</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[(@text = 'Môi trường UAT AWS' or . = 'Môi trường UAT AWS')]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
