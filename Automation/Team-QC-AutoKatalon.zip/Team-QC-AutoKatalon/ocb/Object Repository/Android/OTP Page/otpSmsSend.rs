<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>otpSmsSend</name>
   <tag></tag>
   <elementGuidId>b064e30e-0ea7-4046-a74c-f0cc18a11ebc</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@class = 'android.widget.CheckedTextView' and (@text = 'SMS_GATEWAY' or . = 'SMS_GATEWAY') and @resource-id = 'android:id/text1']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
