<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>searchBarChrome</name>
   <tag></tag>
   <elementGuidId>92c8e85e-8824-4ed9-be04-8dcb210d4fb5</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.EditText[@resource-id=&quot;com.android.chrome:id/search_box_text&quot;]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
