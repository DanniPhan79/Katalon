<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>selectFirstLine</name>
   <tag></tag>
   <elementGuidId>845e6ae0-4b02-456c-9977-02026496980e</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@class = 'android.widget.TextView' and (@text = '10.102.60.7:8060/sms.aspx' or . = '10.102.60.7:8060/sms.aspx') and @resource-id = 'com.android.chrome:id/line_1']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
