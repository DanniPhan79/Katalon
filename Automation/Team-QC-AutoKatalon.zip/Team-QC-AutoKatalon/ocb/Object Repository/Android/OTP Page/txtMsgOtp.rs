<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>txtMsgOtp</name>
   <tag></tag>
   <elementGuidId>5b5dbc6b-0003-4963-9263-b668b9f0c6cd</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.view.View[${index}]/android.view.View[3]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
