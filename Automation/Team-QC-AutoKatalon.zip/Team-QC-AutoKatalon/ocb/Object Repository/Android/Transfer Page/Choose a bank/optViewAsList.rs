<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>optViewAsList</name>
   <tag></tag>
   <elementGuidId>6a8ab639-1ae0-4238-a97d-d39ce2d68b65</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//android.widget.EditText[@text=&quot;Tìm kiếm&quot;]/../..//android.widget.ImageView)[2]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
