<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>selectBank</name>
   <tag></tag>
   <elementGuidId>91447101-255f-4db6-8374-2facab1ad5e7</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//android.widget.TextView[contains(@text,&quot;${text}&quot;)])[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
