<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>txtSearch</name>
   <tag></tag>
   <elementGuidId>658ad6b4-a7a6-49ca-a82e-ec8b2f90b0df</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.EditText[@text=&quot;Tìm kiếm&quot;]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
