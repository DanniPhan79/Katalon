<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnGetOtp</name>
   <tag></tag>
   <elementGuidId>f8e5dffe-bbfd-44b0-a6af-bea93598a7de</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@class = 'android.widget.TextView' and (@text = 'Lấy OTP' or . = 'Lấy OTP')]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
