<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>buttonBackHomePage</name>
   <tag></tag>
   <elementGuidId>63a29af0-c88b-4a82-b090-d504062522ea</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[contains(@text,'Về trang chủ')]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
