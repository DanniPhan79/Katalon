<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>buttonConfirm</name>
   <tag></tag>
   <elementGuidId>ed3c8845-5d5b-4dc9-acdb-6fac0013ba61</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[contains(@text,'Xác nhận')])[2]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
