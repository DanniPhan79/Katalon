<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>buttonContinue</name>
   <tag></tag>
   <elementGuidId>fd0e6512-ec0e-440a-955f-a0135b6e2b5d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[contains(@text,'Tiếp tục')])[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
