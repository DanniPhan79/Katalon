<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>buttonDiffBank</name>
   <tag></tag>
   <elementGuidId>1c197b74-4c81-4dde-b3ef-f97c610b91fb</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[contains(@text,'Ngân hàng khác')]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
