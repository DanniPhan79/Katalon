<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>buttonNormalTranferMoney</name>
   <tag></tag>
   <elementGuidId>42d62898-b21d-464f-b083-fca5ea531573</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[contains(@text,'Chuyển tiền thường')])[2]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
