<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>inputAmount</name>
   <tag></tag>
   <elementGuidId>0ec95fd6-39f4-4ff7-a3c9-be6b6e6cd295</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[contains(@text,'Số tiền cần chuyển')])[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
