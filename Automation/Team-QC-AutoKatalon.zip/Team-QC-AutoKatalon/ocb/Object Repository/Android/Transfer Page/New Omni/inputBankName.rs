<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>inputBankName</name>
   <tag></tag>
   <elementGuidId>ff15a872-ac30-47dc-a44d-b5317cb2ca47</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[contains(@text,'Nhập tên ngân hàng')]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
