<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>inputReceiverName</name>
   <tag></tag>
   <elementGuidId>2b08226c-0950-4d45-a759-0b50ce52c018</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[contains(@text,'Tên người nhận')])[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
