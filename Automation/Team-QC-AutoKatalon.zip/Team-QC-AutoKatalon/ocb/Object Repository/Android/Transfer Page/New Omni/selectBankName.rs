<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>selectBankName</name>
   <tag></tag>
   <elementGuidId>4c6a9c1b-d40a-4d49-acdf-cb9a9579cbf3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.view.ViewGroup[1]/android.widget.TextView[2]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
