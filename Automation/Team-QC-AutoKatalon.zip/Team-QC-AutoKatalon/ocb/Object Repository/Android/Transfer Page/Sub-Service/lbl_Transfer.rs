<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>lbl_Transfer</name>
   <tag></tag>
   <elementGuidId>5315c54f-cbb6-4d38-9672-fbd5ef73d58b</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[contains(@text,'Chuyển tiền')]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
