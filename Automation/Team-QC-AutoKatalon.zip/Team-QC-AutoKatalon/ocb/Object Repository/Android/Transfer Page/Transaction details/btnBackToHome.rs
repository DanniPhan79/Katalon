<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnBackToHome</name>
   <tag></tag>
   <elementGuidId>d79cda0b-f728-4995-9964-efa91d0a2723</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//android.widget.TextView[@text=&quot;Chi tiết giao dịch&quot;]/..//android.widget.ImageView)[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
