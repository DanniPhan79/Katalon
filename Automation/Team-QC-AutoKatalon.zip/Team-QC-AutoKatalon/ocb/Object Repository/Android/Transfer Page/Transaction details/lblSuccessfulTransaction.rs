<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>lblSuccessfulTransaction</name>
   <tag></tag>
   <elementGuidId>860cc9a1-0bcb-4e3d-aeff-3c9925dd02e3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text=&quot;Giao dịch thành công&quot;]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
