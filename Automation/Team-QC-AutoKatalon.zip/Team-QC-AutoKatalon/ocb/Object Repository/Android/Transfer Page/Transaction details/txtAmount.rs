<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>txtAmount</name>
   <tag></tag>
   <elementGuidId>7ce5343c-f9d1-488d-bb7f-1c0a2b94ae03</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@class = 'android.widget.TextView' and (@text = '${text} VND' or . = '${text} VND')]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
