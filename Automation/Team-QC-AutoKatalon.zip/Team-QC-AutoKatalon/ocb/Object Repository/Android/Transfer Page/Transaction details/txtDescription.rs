<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>txtDescription</name>
   <tag></tag>
   <elementGuidId>6c144f43-470c-4053-8878-9cb87d334ffd</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//android.widget.TextView[@text=&quot;Nội dung giao dịch&quot;]/following-sibling::android.widget.TextView)[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
