<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>txtToAccountNumber</name>
   <tag></tag>
   <elementGuidId>ac4a8dd7-e9c3-4e3e-8dcd-8ee59c62608d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
