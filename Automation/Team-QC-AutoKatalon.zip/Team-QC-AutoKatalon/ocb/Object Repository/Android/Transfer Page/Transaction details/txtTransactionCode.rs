<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>txtTransactionCode</name>
   <tag></tag>
   <elementGuidId>c3cfe931-e937-4e52-90bf-bb0fea289a50</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//android.widget.TextView[@text=&quot;Mã giao dịch&quot;]/following-sibling::android.widget.TextView)[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
