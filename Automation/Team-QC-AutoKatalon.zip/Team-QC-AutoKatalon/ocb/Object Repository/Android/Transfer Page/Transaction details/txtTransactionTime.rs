<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>txtTransactionTime</name>
   <tag></tag>
   <elementGuidId>b7bd6168-fe88-4ca6-ad7c-ff08966f576d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//android.widget.TextView[@text=&quot;Thời gian thực hiện&quot;]/following-sibling::android.widget.TextView)[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
