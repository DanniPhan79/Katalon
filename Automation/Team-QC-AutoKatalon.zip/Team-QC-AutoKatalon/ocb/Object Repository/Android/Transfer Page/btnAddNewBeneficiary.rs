<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnAddNewBeneficiary</name>
   <tag></tag>
   <elementGuidId>ee490e59-a08f-4b37-b039-3b7bec9abf61</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>android.widget.TextView</value>
      <webElementGuid>22575a49-e2a2-4ba2-8cc0-326d8f376e62</webElementGuid>
   </webElementProperties>
   <locator>//*[@class = 'android.widget.TextView']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
