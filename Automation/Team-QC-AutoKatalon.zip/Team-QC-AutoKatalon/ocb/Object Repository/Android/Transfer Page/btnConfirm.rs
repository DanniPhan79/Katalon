<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnConfirm</name>
   <tag></tag>
   <elementGuidId>755ae592-2c89-438d-bcf3-40ec528b93b8</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@class = 'android.widget.TextView' and (@text = 'Xác nhận' or . = 'Xác nhận')]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
