<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnTransfer</name>
   <tag></tag>
   <elementGuidId>5ff82847-91b5-4c22-aa3b-5d2f6db65175</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@resource-id='FAST_TRANSFER_TRANSFER_BTN']//android.widget.TextView[@text=&quot;Chuyển tiền&quot;]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
