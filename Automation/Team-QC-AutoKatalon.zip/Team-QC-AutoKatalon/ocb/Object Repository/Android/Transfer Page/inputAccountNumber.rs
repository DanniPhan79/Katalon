<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>inputAccountNumber</name>
   <tag></tag>
   <elementGuidId>ef799a5e-c4e3-4ba2-8d17-e6439182e8e7</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@class = 'android.widget.EditText' and (@text = 'Nhập số tài khoản' or . = 'Nhập số tài khoản')]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
