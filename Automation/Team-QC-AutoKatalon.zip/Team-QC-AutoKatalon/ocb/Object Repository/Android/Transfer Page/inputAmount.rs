<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>inputAmount</name>
   <tag></tag>
   <elementGuidId>c4f1a112-dfc2-44f8-8204-7d9242e96fbe</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@class = 'android.widget.EditText' and (@text = 'Nhập số tiền' or . = 'Nhập số tiền')]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
