<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>inputMessage</name>
   <tag></tag>
   <elementGuidId>176b3ce5-cc72-4707-a666-1335c71f5484</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.EditText[@hint=&quot;Nhập tên gợi nhớ&quot;]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
