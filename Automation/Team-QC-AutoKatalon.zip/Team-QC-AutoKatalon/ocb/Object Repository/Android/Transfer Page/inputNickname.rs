<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>inputNickname</name>
   <tag></tag>
   <elementGuidId>f7a34c35-2678-4b09-8afd-6033d0cd23bd</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@class = 'android.widget.EditText' and (@text = 'Nhập tên gợi nhớ' or . = 'Nhập tên gợi nhớ')]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
