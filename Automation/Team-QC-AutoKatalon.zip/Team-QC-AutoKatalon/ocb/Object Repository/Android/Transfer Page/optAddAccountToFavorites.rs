<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>optAddAccountToFavorites</name>
   <tag></tag>
   <elementGuidId>74d718db-df70-46b7-b12d-8eae6a98bd7d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.view.ViewGroup[11]/android.view.ViewGroup[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
