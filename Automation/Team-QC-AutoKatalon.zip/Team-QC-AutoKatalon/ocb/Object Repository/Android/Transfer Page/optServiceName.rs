<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>optServiceName</name>
   <tag></tag>
   <elementGuidId>ab08e742-b551-465b-8a51-29b11a4c8bf2</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>'${text}'</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
