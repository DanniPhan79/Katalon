<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>optTo</name>
   <tag></tag>
   <elementGuidId>80a2fd17-40e2-44c7-ae4b-091f744cf4e1</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.TextView[@text=&quot;${text}&quot;]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
