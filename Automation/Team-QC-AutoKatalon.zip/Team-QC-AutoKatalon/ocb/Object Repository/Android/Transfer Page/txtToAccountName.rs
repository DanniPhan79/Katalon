<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>txtToAccountName</name>
   <tag></tag>
   <elementGuidId>89bfecd7-cb53-4c8f-a6f5-3a670451a5b3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//android.widget.EditText[@hint=&quot;Nhập tên gợi nhớ&quot;]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
