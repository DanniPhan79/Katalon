<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btnDashboard</name>
   <tag></tag>
   <elementGuidId>43dd469f-9f73-4cf8-a315-2fbdd99f61a9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//*[contains(text(), &quot;Về trang chủ&quot;)])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>2bd2f56b-50b6-4645-a524-08fb29038b52</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-if</name>
      <type>Main</type>
      <value>currency == 'VND'</value>
      <webElementGuid>16e950f0-ab41-42d7-925e-e17a380a6a7e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bd-amount__value mg-right</value>
      <webElementGuid>b2e66166-6389-44dc-85d0-8dad2795f006</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>c62d66b5-0b87-455d-b0c9-27259dcf2aa7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;accounts&quot;)/div[@class=&quot;widget-tile-content&quot;]/div[@class=&quot;widget-content-inner&quot;]/div[@class=&quot;horizontal-split-panels&quot;]/section[3]/div[@class=&quot;slide-widget-container&quot;]/div[1]/div[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-10&quot;]/div[@id=&quot;slide-widget-content&quot;]/ul[@class=&quot;widget-slide-box&quot;]/li[1]/div[1]/div[1]/div[@class=&quot;accounts widget-content&quot;]/div[1]/div[1]/div[2]/div[@class=&quot;bd-amount&quot;]/span[@class=&quot;bd-amount__value mg-right&quot;]</value>
      <webElementGuid>b0cf3407-357b-4735-80c4-aa43bbee82bf</webElementGuid>
   </webElementProperties>
</WebElementEntity>
