<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txtAvailablefunds</name>
   <tag></tag>
   <elementGuidId>c71319a9-7dd8-4036-9497-6c4f4bc3ef7a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@class = 'title-2 ng-star-inserted']</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>a752415c-d20e-4f25-9fff-0222b58e33b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-if</name>
      <type>Main</type>
      <value>currency == 'VND'</value>
      <webElementGuid>6d81afa6-fa7f-40fe-a6b8-022fcd58e981</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bd-amount__value mg-right</value>
      <webElementGuid>b6d919bc-e573-4285-a3f8-b4abf312c282</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>bae9611b-af68-4330-8fa3-be74832b1123</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;accounts&quot;)/div[@class=&quot;widget-tile-content&quot;]/div[@class=&quot;widget-content-inner&quot;]/div[@class=&quot;horizontal-split-panels&quot;]/section[3]/div[@class=&quot;slide-widget-container&quot;]/div[1]/div[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-10&quot;]/div[@id=&quot;slide-widget-content&quot;]/ul[@class=&quot;widget-slide-box&quot;]/li[1]/div[1]/div[1]/div[@class=&quot;accounts widget-content&quot;]/div[1]/div[1]/div[2]/div[@class=&quot;bd-amount&quot;]/span[@class=&quot;bd-amount__value mg-right&quot;]</value>
      <webElementGuid>88520e10-fc78-4b8e-9b63-8d457a35aa82</webElementGuid>
   </webElementProperties>
</WebElementEntity>
