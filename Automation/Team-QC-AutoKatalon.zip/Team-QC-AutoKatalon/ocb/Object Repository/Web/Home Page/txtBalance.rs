<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txtBalance</name>
   <tag></tag>
   <elementGuidId>16eb8720-3a40-48be-a6cd-30c93928788e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
<<<<<<<< HEAD:Object Repository/Web/Home Page/txtBalance.rs
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Số dư khả dụng'])[3]/following::span[1]</value>
========
         <value>li.active > div.nav-submenu.submenu_visible > div > span</value>
>>>>>>>> main:Object Repository/Web/Page Transfer Money/tabSendmoney.rs
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//aside[@id='side-nav']/ul/li[7]/div[2]/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
<<<<<<<< HEAD:Object Repository/Web/Home Page/txtBalance.rs
      <webElementGuid>77fe47f8-cb63-4b87-81c6-9494c9036727</webElementGuid>
========
      <webElementGuid>b3e3b68a-3f8d-4c51-b3f3-6641096336ba</webElementGuid>
>>>>>>>> main:Object Repository/Web/Page Transfer Money/tabSendmoney.rs
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-if</name>
      <type>Main</type>
<<<<<<<< HEAD:Object Repository/Web/Home Page/txtBalance.rs
      <value>currency == 'VND'</value>
      <webElementGuid>b2a1224e-cab3-4099-b8ae-add23b99a4db</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bd-amount__value mg-right</value>
      <webElementGuid>a9af1cec-803d-4d15-adf0-a76cfbb2c5bc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>7193d5e2-3b79-4f89-9946-2b96cd7ae047</webElementGuid>
========
      <value>{'submenuItem.silver':userDetails.customerDetails.packageType=='SILVER'}</value>
      <webElementGuid>0edd4bd8-106f-4240-99a1-20cbd182c7fd</webElementGuid>
>>>>>>>> main:Object Repository/Web/Page Transfer Money/tabSendmoney.rs
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
<<<<<<<< HEAD:Object Repository/Web/Home Page/txtBalance.rs
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;accounts&quot;)/div[@class=&quot;widget-tile-content&quot;]/div[@class=&quot;widget-content-inner&quot;]/div[@class=&quot;horizontal-split-panels&quot;]/section[3]/div[@class=&quot;slide-widget-container&quot;]/div[1]/div[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-10&quot;]/div[@id=&quot;slide-widget-content&quot;]/ul[@class=&quot;widget-slide-box&quot;]/li[1]/div[1]/div[1]/div[@class=&quot;accounts widget-content&quot;]/div[1]/div[1]/div[2]/div[@class=&quot;bd-amount&quot;]/span[@class=&quot;bd-amount__value mg-right&quot;]</value>
      <webElementGuid>7585d1b1-4285-44f2-a6ea-447f6a2a6364</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='slide-widget-content']/ul/li/div/div/div/div/div/div[2]/div/span</value>
      <webElementGuid>ddb11ad3-24bd-4e8e-98a8-a8820cd097ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Số dư khả dụng'])[3]/following::span[1]</value>
      <webElementGuid>443a22c9-d51b-49e0-988b-8887fe060216</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Các TK VND: 1'])[1]/following::span[1]</value>
      <webElementGuid>60ee4d0e-5e0c-4e2e-bfef-cfa684f2b574</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='VND'])[13]/preceding::span[1]</value>
      <webElementGuid>847c4786-f023-45ee-ac78-6951f2ca64a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Số dư'])[3]/preceding::span[3]</value>
      <webElementGuid>96d3b30d-26c6-4a66-993c-e98fc71d7b57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/div/div/div/div/div/div[2]/div/span</value>
      <webElementGuid>098ce256-51ad-4a1b-8d92-a73ef5295a9b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '0' or . = '0')]</value>
      <webElementGuid>ec880b97-6b95-412a-9d63-effef0d7242e</webElementGuid>
   </webElementXpaths>
========
      <name>text</name>
      <type>Main</type>
      <value>Chuyển tiền</value>
      <webElementGuid>9a9c820c-9b2d-4324-936c-b934b48906dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;side-nav&quot;)/ul[@class=&quot;nav-ul&quot;]/li[@class=&quot;active&quot;]/div[@class=&quot;nav-submenu submenu_visible&quot;]/div[1]/span[1]</value>
      <webElementGuid>63dc1e81-7f75-4b7b-8fbc-a7b766a9b0d5</webElementGuid>
   </webElementProperties>
>>>>>>>> main:Object Repository/Web/Page Transfer Money/tabSendmoney.rs
</WebElementEntity>
