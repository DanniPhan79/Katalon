<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txtTotalBalance</name>
   <tag></tag>
   <elementGuidId>880832c8-ece8-4bda-955c-42aa1525a00a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//*[normalize-space(text()) and normalize-space(.)='Số dư'])/following::span[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>f630b905-4fe9-457a-8107-183fc564f9d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-if</name>
      <type>Main</type>
      <value>currency == 'VND'</value>
      <webElementGuid>51dcc10b-0f99-46f8-8395-4e29636dd225</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bd-amount__value mg-right</value>
      <webElementGuid>5bd2c6bb-bd8a-47b6-9875-369ad447ff1a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>d54312c7-285b-4464-8c94-24f91ba8d781</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;accounts&quot;)/div[@class=&quot;widget-tile-content&quot;]/div[@class=&quot;widget-content-inner&quot;]/div[@class=&quot;horizontal-split-panels&quot;]/section[3]/div[@class=&quot;slide-widget-container&quot;]/div[1]/div[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-10&quot;]/div[@id=&quot;slide-widget-content&quot;]/ul[@class=&quot;widget-slide-box&quot;]/li[1]/div[1]/div[1]/div[@class=&quot;accounts widget-content&quot;]/div[1]/div[1]/div[2]/div[@class=&quot;bd-amount&quot;]/span[@class=&quot;bd-amount__value mg-right&quot;]</value>
      <webElementGuid>ab99d113-3462-4cde-b4a9-3fe623183cda</webElementGuid>
   </webElementProperties>
</WebElementEntity>
