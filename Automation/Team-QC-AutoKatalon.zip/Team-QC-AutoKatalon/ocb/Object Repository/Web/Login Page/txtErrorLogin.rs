<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txtErrorLogin</name>
   <tag></tag>
   <elementGuidId>abb349b7-fa76-4f49-9206-81882585461f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@class='control-label error login-page-error']/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>9ff40eeb-2030-4033-9ef9-56d6799d6707</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Tên đăng nhập hoặc mật khẩu không hợp lệ. Vui lòng thử lại.</value>
      <webElementGuid>8504d880-8b8c-4928-a4b4-350675fa0604</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;background&quot;)/div[@class=&quot;main__contain&quot;]/div[@class=&quot;main__contain-body&quot;]/div[@class=&quot;main__contain-input&quot;]/div[@class=&quot;main__contain-input-body&quot;]/div[@class=&quot;main__contain-input-form&quot;]/div[@class=&quot;logon-step-animation-container next-animation&quot;]/div[1]/div[@class=&quot;animate-on logon-step-animation&quot;]/div[1]/form[@class=&quot;ng-valid-maxlength ng-dirty ng-invalid ng-invalid-required&quot;]/div[@class=&quot;form-row error-group login-error&quot;]/label[@class=&quot;control-label error login-page-error&quot;]/div[1]/span[1]</value>
      <webElementGuid>df3e96d2-91c5-4c2b-911a-d136fa50c928</webElementGuid>
   </webElementProperties>
</WebElementEntity>
