<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonSendMoneyToTheRecicpient</name>
   <tag></tag>
   <elementGuidId>f1d7aab0-f50b-49ff-8944-385c3709e148</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id='btn-createPayment ']/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>7dce898a-7fbc-45bd-b6b6-b8a5b8365964</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Chuyển tiền cho người thụ hưởng</value>
      <webElementGuid>dbc6973e-cb1e-4a06-b694-83818575afea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;btn-createPayment &quot;)/span[1]</value>
      <webElementGuid>1853261f-d928-48fc-8108-540a0f06277b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
