<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>tabSendmoney</name>
   <tag></tag>
   <elementGuidId>b5d7bff5-969a-4bfc-bd99-5a64e76dfc9e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.active > div.nav-submenu.submenu_visible > div > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@class='nav-submenu submenu_visible']/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>05cd07fa-14da-4a65-b7b5-68897065341a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-class</name>
      <type>Main</type>
      <value>{'submenuItem.silver':userDetails.customerDetails.packageType=='SILVER'}</value>
      <webElementGuid>8f77b516-86e2-4120-8bbb-f7e221d05723</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Chuyển tiền</value>
      <webElementGuid>302b62e4-86db-407e-bb8d-6c251880676a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;side-nav&quot;)/ul[@class=&quot;nav-ul&quot;]/li[@class=&quot;active&quot;]/div[@class=&quot;nav-submenu submenu_visible&quot;]/div[1]/span[1]</value>
      <webElementGuid>5ec23fbe-b467-4605-b073-a66a1c45968c</webElementGuid>
   </webElementProperties>
</WebElementEntity>
