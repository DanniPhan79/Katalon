<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>lbl_text contains</name>
   <tag></tag>
   <elementGuidId>ac52e321-915a-47c8-9817-f405674e2c6f</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//[contains(@text,&quot;${text}&quot;)]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
