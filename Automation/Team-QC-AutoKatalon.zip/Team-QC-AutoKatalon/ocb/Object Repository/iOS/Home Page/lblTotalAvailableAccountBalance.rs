<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>lblTotalAvailableAccountBalance</name>
   <tag></tag>
   <elementGuidId>48d4d803-263f-4a83-9b0e-90ae058e7abf</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
