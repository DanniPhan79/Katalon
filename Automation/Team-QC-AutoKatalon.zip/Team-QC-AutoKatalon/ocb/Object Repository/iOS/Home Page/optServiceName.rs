<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>optServiceName</name>
   <tag></tag>
   <elementGuidId>3cf90ac1-0f77-489a-9c9c-38d07d17bf73</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>'${text}'</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
