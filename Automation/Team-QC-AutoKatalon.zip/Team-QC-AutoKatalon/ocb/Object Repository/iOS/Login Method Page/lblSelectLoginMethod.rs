<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>lblSelectLoginMethod</name>
   <tag></tag>
   <elementGuidId>be71c1f9-8a16-49f1-9107-7879434cdaf3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
