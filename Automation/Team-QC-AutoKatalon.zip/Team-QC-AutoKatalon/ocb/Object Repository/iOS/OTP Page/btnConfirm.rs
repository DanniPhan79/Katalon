<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnConfirm</name>
   <tag></tag>
   <elementGuidId>8963d64e-1637-45bf-96d2-79cfe62ebdae</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@type = 'XCUIElementTypeButton' and @label = 'Clear Text' and @name = 'Clear Text']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
