<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>inputSoDt</name>
   <tag></tag>
   <elementGuidId>52eccaa5-386f-4fc9-ad76-38855b28e40c</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@name = 'Nhập các số cuối hoặc không nhập' or @value = '749']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
