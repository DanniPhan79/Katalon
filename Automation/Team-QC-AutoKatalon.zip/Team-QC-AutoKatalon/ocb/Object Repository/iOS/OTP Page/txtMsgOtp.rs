<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>txtMsgOtp</name>
   <tag></tag>
   <elementGuidId>437f5a5c-4e27-476d-9d7b-330213d744bd</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//XCUIElementTypeOther[${index}]/XCUIElementTypeOther[3]/XCUIElementTypeStaticText[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
