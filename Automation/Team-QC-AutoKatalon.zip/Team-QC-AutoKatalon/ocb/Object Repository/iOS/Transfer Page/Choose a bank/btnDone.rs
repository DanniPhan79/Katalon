<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnDone</name>
   <tag></tag>
   <elementGuidId>d880d57e-6551-41ad-9c51-01e1b748b0e2</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[@label = 'Done' or @name = 'Done'])[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
