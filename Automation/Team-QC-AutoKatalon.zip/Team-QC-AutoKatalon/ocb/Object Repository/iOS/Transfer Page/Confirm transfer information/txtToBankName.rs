<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>txtToBankName</name>
   <tag></tag>
   <elementGuidId>880ce38c-4bcf-4cac-a0c4-851abe5ef5c7</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
