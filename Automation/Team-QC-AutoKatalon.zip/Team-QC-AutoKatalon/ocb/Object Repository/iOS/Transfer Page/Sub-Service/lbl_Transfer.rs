<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>lbl_Transfer</name>
   <tag></tag>
   <elementGuidId>0617bc82-b0d9-4f64-b625-bfb62bd7adc3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@resource-id='Transfer']//android.widget.TextView[@text = 'Chuyển tiền' or . = 'Chuyển tiền']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
