<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>txtFromAccountName</name>
   <tag></tag>
   <elementGuidId>b86dcece-3cf5-4c48-a2d5-5853654e41ed</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
