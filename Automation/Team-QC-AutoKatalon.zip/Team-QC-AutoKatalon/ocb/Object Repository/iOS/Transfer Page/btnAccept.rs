<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnAccept</name>
   <tag></tag>
   <elementGuidId>2b8c011f-6827-4454-bff1-75280ea57053</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@type = 'XCUIElementTypeStaticText' and @label = 'Đồng ý' and @name = 'Đồng ý' and @value = 'Đồng ý']</locator>
   <locatorStrategy>ATTRIBUTES</locatorStrategy>
</MobileElementEntity>
