<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnBackToHomePage</name>
   <tag></tag>
   <elementGuidId>f3eb79f5-7055-431c-a2e7-1f226a88c630</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[@label = 'Về trang chủ' or @name = 'Về trang chủ' or @value = 'Về trang chủ'])[2]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
