<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnConfirm</name>
   <tag></tag>
   <elementGuidId>af4a9ea0-2af3-4bbc-bb32-5794a9fb5fe0</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[@label = 'Xác nhận' or @name = 'Xác nhận' or @value = 'Xác nhận'])[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
