<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnInputTranferMoneyDone</name>
   <tag></tag>
   <elementGuidId>e98a2532-5d7d-4d64-af45-1fc9d641fba8</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[@label = 'Xong' or @name = 'Xong' or @value = 'Xong'])[2]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
