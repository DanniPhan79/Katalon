<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnLogin</name>
   <tag></tag>
   <elementGuidId>c0daa0ea-d9f6-487e-8fc5-ce71534e96fc</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[@label = 'Đăng nhập' or @name = 'Đăng nhập' or @value = 'Đăng nhập'])[1]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
