<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnLogout</name>
   <tag></tag>
   <elementGuidId>991ac145-8fc0-43e7-baa2-94a0d3b2e202</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@type = 'XCUIElementTypeButton' and @label = 'Đăng xuất' and @name = 'Đăng xuất']</locator>
   <locatorStrategy>ATTRIBUTES</locatorStrategy>
</MobileElementEntity>
