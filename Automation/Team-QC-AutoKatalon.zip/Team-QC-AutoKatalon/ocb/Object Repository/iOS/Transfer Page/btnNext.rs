<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>btnNext</name>
   <tag></tag>
   <elementGuidId>c26c26b4-23f4-406c-b9d8-e0a0e313203e</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>(//*[@label = 'Tiếp tục' or @name = 'Tiếp tục' or @value = 'Tiếp tục'])[2]</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
