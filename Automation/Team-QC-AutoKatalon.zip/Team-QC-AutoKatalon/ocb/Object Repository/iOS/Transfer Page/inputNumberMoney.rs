<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>inputNumberMoney</name>
   <tag></tag>
   <elementGuidId>617d257b-97bf-48a8-8ec9-efb61bf6a536</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@label = 'Số tiền cần chuyển' or @name = 'Số tiền cần chuyển' or @value = 'Số tiền cần chuyển']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
