<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>inputPassword</name>
   <tag></tag>
   <elementGuidId>6eebc194-1cc1-4841-9eab-e5852aadf365</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//*[@label = 'Mật khẩu' or @name = 'Mật khẩu' or @value = 'Mật khẩu']</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
