<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>inputSecurityPass</name>
   <tag></tag>
   <elementGuidId>e3826705-7092-4e8a-b083-83ed329b1043</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>//XCUIElementTypeOther[1]/XCUIElementTypeSecureTextField</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
