<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>optAddAccountToFavorites</name>
   <tag></tag>
   <elementGuidId>b773330e-dd93-424c-9de0-31ae4ea5b305</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
