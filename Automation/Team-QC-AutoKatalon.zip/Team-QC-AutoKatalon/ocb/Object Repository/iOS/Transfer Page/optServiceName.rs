<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>optServiceName</name>
   <tag></tag>
   <elementGuidId>b67104d9-1862-4a77-863c-711f20c0e8fe</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>'${text}'</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
