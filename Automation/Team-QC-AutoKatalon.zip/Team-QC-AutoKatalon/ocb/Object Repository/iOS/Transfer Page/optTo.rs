<?xml version="1.0" encoding="UTF-8"?>
<MobileElementEntity>
   <description></description>
   <name>optTo</name>
   <tag></tag>
   <elementGuidId>c2d09ab8-4ed7-4a18-b8ab-4d462f008368</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <locator>${text}</locator>
   <locatorStrategy>XPATH</locatorStrategy>
</MobileElementEntity>
